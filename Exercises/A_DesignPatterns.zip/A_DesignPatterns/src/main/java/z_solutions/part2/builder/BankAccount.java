package z_solutions.part2.builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class BankAccount {

	private final long accountNumber;
	private final String owner;
	private final String branch;
	private double balance;
	private double interestRate;

	public static class Builder {

		private final long accountNumber; 
		private final String owner;
		private String branch = ""; // Optional field
		private double balance;
		private double interestRate;

		public Builder(long accountNumber, String owner) {
			this.accountNumber = accountNumber;
			this.owner = owner;
		}

		public Builder atBranch(String branch) {
			this.branch = branch;
			return this;
		}

		public Builder noBranch() {
			this.branch = "";
			return this;
		}
		
		public Builder withBalance(double balance) {
			this.balance = balance;
			return this;
		}

		public Builder atRate(double interestRate) {
			this.interestRate = interestRate;
			return this;
		}

		public BankAccount build() {
			return new BankAccount(accountNumber, owner, branch, balance, interestRate);
		}
	}

	/*private*/ BankAccount(long accountNumber, String owner, String branch, double balance, double interestRate) {
		this.accountNumber = accountNumber;
		this.owner = owner;
		this.branch = branch;
		this.balance = balance;
		this.interestRate = interestRate;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber + ", owner=" + owner + ", branch=" + branch + ", balance="
				+ balance + ", interestRate=" + interestRate + "]";
	}	
}
