package z_solutions.part2.builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class BankAccountExample {

	public static void main(String[] args) {
		
		BankAccount normalAccount = new BankAccount.Builder(456L, "James").
				                        atBranch("Zurich").
				                        withBalance(100.00).
				                        atRate(2.5).
				                        build();
				                        
        //  Achtung: beim zweiten Mal ist der Zinssatz 200 %, gute Rendite :-)
		//Oops! Aber sofort sichtbar!
        BankAccount anotherAccount = new BankAccount.Builder(789L, "Michael").
				                        noBranch().
				                        withBalance(2.5).
				                        atRate(200).
				                        build();
        
        System.out.println(normalAccount);
        System.out.println(anotherAccount);
	}
}
