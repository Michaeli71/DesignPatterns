package z_solutions.part2.factory;

public class GameEntity {

}
