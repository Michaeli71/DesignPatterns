package z_solutions.part2.factory;

import z_erercises.part2.factory.Endurance;
import z_erercises.part2.factory.LowerBody;
import z_erercises.part2.factory.UpperBody;
import z_erercises.part2.factory.Workout;
import z_erercises.part2.factory.WorkoutType;

public class WorkoutFactory 
{ 
    public static Workout getWorkout(WorkoutType workoutType) {
        switch (workoutType) {
            case UPPERBODY: {
                return new UpperBody();
            }
            case LOWERBODY: {
                return new LowerBody();
            }
            case ENDURANCE: {
                return new Endurance();
            }
            default: {
                throw new IllegalStateException("unsupported workout type");
            }
        }
    }
}