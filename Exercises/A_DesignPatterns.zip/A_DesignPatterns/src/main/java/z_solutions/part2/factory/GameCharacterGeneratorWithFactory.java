package z_solutions.part2.factory;

public class GameCharacterGeneratorWithFactory {

	public static void main(String[] args) {
		
		GameEntity ufo = GameCharacterFactory.createGameEntity("UFO");
		GameEntity bullet = GameCharacterFactory.createGameEntity("BULLET");
		GameEntity player = GameCharacterFactory.createGameEntity("PLAYER");
	}
}
