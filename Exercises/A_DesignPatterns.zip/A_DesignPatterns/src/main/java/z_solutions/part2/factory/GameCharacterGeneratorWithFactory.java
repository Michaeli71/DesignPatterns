package z_solutions.part2.factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class GameCharacterGeneratorWithFactory
{
    public static void main(String[] args)
    {

        GameEntity ufo = GameCharacterFactory.createGameEntity("UFO");
        GameEntity bullet = GameCharacterFactory.createGameEntity("BULLET");
        GameEntity player = GameCharacterFactory.createGameEntity("PLAYER");
    }
}
