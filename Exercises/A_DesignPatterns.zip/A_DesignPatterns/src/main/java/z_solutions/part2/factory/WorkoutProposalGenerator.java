package z_solutions.part2.factory;

import z_erercises.part2.factory.Workout;
import z_erercises.part2.factory.WorkoutType;

public class WorkoutProposalGenerator {
 
    public static void main(String[] args) {
        //Retreives the UpperBody object
        Workout workout = WorkoutFactory.getWorkout(WorkoutType.UPPERBODY);
         
        //Calls createWorkout from UpperBody
        workout.createWorkout();
 
        //Retrieves the LowerBody object
        workout = WorkoutFactory.getWorkout(WorkoutType.LOWERBODY);
 
        //Calls createWorkout from LowerBody
        workout.createWorkout();
        
      //Retrieves the LowerBody object
        workout = WorkoutFactory.getWorkout(WorkoutType.ENDURANCE);
 
        //Calls createWorkout from LowerBody
        workout.createWorkout();
    }
}