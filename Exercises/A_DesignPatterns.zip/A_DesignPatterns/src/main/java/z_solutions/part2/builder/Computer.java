package z_solutions.part2.builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Computer {

	// required parameters
	private String sdd;
	private String ram;

	// optional parameters
	private boolean isGraphicsCardEnabled;
	private boolean isBluetoothEnabled;

	public String getSSD() {
		return sdd;
	}

	public String getRAM() {
		return ram;
	}

	public boolean isGraphicsCardEnabled() {
		return isGraphicsCardEnabled;
	}

	public boolean isBluetoothEnabled() {
		return isBluetoothEnabled;
	}

	private Computer(ComputerBuilder builder) {
		this.sdd = builder.ssd;
		this.ram = builder.ram;
		this.isGraphicsCardEnabled = builder.isGraphicsCardEnabled;
		this.isBluetoothEnabled = builder.isBluetoothEnabled;
	}

	// Builder Class
	public static class ComputerBuilder {

		// required parameters
		private String ssd;
		private String ram;

		// optional parameters
		private boolean isGraphicsCardEnabled;
		private boolean isBluetoothEnabled;

		public ComputerBuilder(String ssd, String ram) {
			this.ssd = ssd;
			this.ram = ram;
		}

		// BEKANNTE VARIANTE
		// -----------------
		public ComputerBuilder setGraphicsCardEnabled(boolean isGraphicsCardEnabled) {
			this.isGraphicsCardEnabled = isGraphicsCardEnabled;
			return this;
		}

		public ComputerBuilder setBluetoothEnabled(boolean isBluetoothEnabled) {
			this.isBluetoothEnabled = isBluetoothEnabled;
			return this;
		}
		
		// SCHÖNERE VARIANTE
		// -----------------
		public ComputerBuilder withGraphicsCardEnabled() {
			this.isGraphicsCardEnabled = true;
			return this;
		}

		public ComputerBuilder nohGraphicsCard() {
			this.isGraphicsCardEnabled = false;
			return this;
		}
		
		public ComputerBuilder withBluetooth() {
			this.isBluetoothEnabled = true;
			return this;
		}

		public ComputerBuilder noBluetooth() {
			this.isBluetoothEnabled = false;
			return this;
		}
		
		public Computer build() {
			return new Computer(this);
		}
	}

	@Override
	public String toString() {
		return "Computer [ssd=" + sdd + ", ram=" + ram + ", isGraphicsCardEnabled=" + isGraphicsCardEnabled
				+ ", isBluetoothEnabled=" + isBluetoothEnabled + "]";
	}
}