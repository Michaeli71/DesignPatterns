package z_solutions.part5.strategy;

public class IsAllLowerCase implements ValidationStrategy {
	@Override
	public boolean validate(String input) {
		return input.matches("[a-z]+");
	}
}
