package z_solutions.part5.strategy;

public class ValidationExample {
	public static void main(String[] args) {
		// old school
		Validator v1 = new Validator(new IsNumeric());
		System.out.println(v1.validate("aaaa"));
		Validator v2 = new Validator(new IsAllLowerCase());
		System.out.println(v2.validate("bbbb"));

		// with lambdas
		 Validator v3 = new Validator(str -> str.matches("\\d+"));
		 System.out.println(v3.validate("aaaa"));
		 Validator v4 = new Validator(str -> str.matches("[a-z]+"));
		 System.out.println(v4.validate("bbbb"));
	}
}
