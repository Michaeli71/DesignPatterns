package z_solutions.part5.strategy;

public class Validator {
	private final ValidationStrategy strategy;

	public Validator(ValidationStrategy strategy) {
		this.strategy = strategy;
	}

	public boolean validate(String input) {
		return strategy.validate(input);
	}
}