package z_solutions.part5.factory;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ProductFactoryJava8
{
    private final static Map<String, Supplier<Product>> map = new HashMap<>();
    static
    {
        map.put("Book", Book::new);
        map.put("Car", Car::new);
        map.put("TV", TV::new);
    }

    public static Product createProductLambda(String name)
    {
        if (map.containsKey(name))
            throw new IllegalArgumentException("No such product " + name);

        Supplier<Product> p = map.get(name);
        return p.get();
    }

    static interface Product
    {
    }

    static class Book implements Product
    {
    }

    static class Car implements Product
    {
    }

    static class TV implements Product
    {
    }
}
