package z_solutions.part5.factory;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class ProductFactoryJava8 
{
	private final static Map<String, Supplier<Product>> map = new HashMap<>();
	static {
		map.put("Book", Book::new);
		map.put("Car", Car::new);
		map.put("Book", Book::new);
	}

	public static Product createProductLambda(String name) {
		if (map.containsKey(name))
			throw new RuntimeException("No such product " + name);

		Supplier<Product> p = map.get(name);
		return p.get();
	}

    static interface Product {}
    static class Book implements Product {}
    static class Car implements Product {}
    static class TV implements Product {}
}
