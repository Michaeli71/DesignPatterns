package z_solutions.part5.strategy_validation;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 *         Copyright 2020 by Michael Inden
 */
public class ValidationExample
{
    public static void main(String[] args)
    {
        // old school
        Validator v1 = new Validator(new IsNumeric());
        System.out.println(v1.validate("12345"));
        System.out.println(v1.validate("wrong"));
        Validator v2 = new Validator(new IsAllLowerCase());
        System.out.println(v2.validate("valid"));

        // with lambdas
        Validator v3 = new Validator(str -> str.matches("[+-]?\\d+"));
        System.out.println(v3.validate("12345"));
        System.out.println(v3.validate("wrong"));
        Validator v4 = new Validator(str -> str.matches("[a-z]+"));
        System.out.println(v4.validate("valid"));
    }
}
