package z_solutions.part5.strategy;

public class IsNumeric implements ValidationStrategy {
	@Override
	public boolean validate(String input) {
		return input.matches("\\d+");
	}
}