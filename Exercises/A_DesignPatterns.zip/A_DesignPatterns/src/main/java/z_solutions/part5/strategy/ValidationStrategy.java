package z_solutions.part5.strategy;

interface ValidationStrategy 
{
	public boolean validate(String input);
}