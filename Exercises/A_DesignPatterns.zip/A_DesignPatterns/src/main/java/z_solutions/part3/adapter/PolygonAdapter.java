package z_solutions.part3.adapter;

public class PolygonAdapter extends BaseFigure {
	private Polygon polygon;

	PolygonAdapter(Polygon polygon)
	{
		this.polygon = polygon;
	}

	@Override
	void draw() {
		polygon.paintBorder();
	}

	@Override
	void fill() {
		polygon.filledWithPattern();			
	}
}
