package z_solutions.part3.proxy_dynamicproxy;

public class InvalidAccessRightsException extends RuntimeException {

	public InvalidAccessRightsException(String msg)
	{
		super(msg);
	}
}
