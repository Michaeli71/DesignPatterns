package z_solutions.part3.adapter;

import java.util.ArrayList;
import java.util.List;

public class DrawingExample {

	public static void main(String[] args) {
		
		List<BaseFigure> figures = new ArrayList<>();
		figures.add(new Circle());
		figures.add(new Circle());
		figures.add(new Rect());

		// how to use Triangle / Polygon
		figures.add(new TriangleAdapter(new Triangle()));
		figures.add(new PolygonAdapter(new Polygon()));
		
		//
		for (BaseFigure fig : figures)
		{
			fig.draw();
		}
	}

}
