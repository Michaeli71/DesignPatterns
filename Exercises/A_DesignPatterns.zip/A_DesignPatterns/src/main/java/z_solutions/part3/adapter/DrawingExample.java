package z_solutions.part3.adapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DrawingExample
{
    public static void main(String[] args)
    {
        List<BaseFigure> figures = new ArrayList<>();
        figures.add(new Circle());
        figures.add(new Circle());
        figures.add(new Rect());

        // how to use Triangle / Polygon
        figures.add(new TriangleAdapter(new Triangle()));
        figures.add(new PolygonAdapter(new Polygon()));

        //
        for (BaseFigure fig : figures)
        {
            fig.draw();
        }
    }
}
