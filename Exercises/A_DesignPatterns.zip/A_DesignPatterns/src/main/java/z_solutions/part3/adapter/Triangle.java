package z_solutions.part3.adapter;

public class Triangle {

	void drawTriangle()
	{
		System.out.println("drawTriangle");
	}

	void fillTriangle()
	{
		System.out.println("fillTriangle");
	}
}
