package z_solutions.part3.adapter;

public abstract class BaseFigure {

	abstract void draw();
	abstract void fill();
}
