package z_solutions.part3.adapter;

public class Circle extends BaseFigure {

	@Override
	void draw() {
		System.out.println("Draw circle");		
	}

	@Override
	void fill() {
		System.out.println("Fill circle");		
	}
}
