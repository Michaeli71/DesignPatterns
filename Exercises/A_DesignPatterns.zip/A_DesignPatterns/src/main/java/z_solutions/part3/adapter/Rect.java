package z_solutions.part3.adapter;

public class Rect extends BaseFigure {

	@Override
	void draw() {
		System.out.println("Draw rect");		
	}

	@Override
	void fill() {
		System.out.println("Fill rect");		
	}
}
