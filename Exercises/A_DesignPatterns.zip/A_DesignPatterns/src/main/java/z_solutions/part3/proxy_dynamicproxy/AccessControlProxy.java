package z_solutions.part3.proxy_dynamicproxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

// Übungsaufgabe !!!!
public class AccessControlProxy<K,V> implements InvocationHandler
{
    private final Map<K,V> map;

    public AccessControlProxy(final Map<K,V> map) 
	{
		this.map = map;
	}

	public void ensureAccessGranted() throws InvalidAccessRightsException {
		System.out.println("checking ensureAccessGranted()");
		
		if (!LoggedInUserService.INSTANCE.getLoggedInUser().equals("ADMIN"))
			throw new InvalidAccessRightsException("Invalid User");
	}
	
    @Override
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable
    {
    	System.out.println("Checking for method: " + method);
    	ensureAccessGranted();

        Object result = null;
        try
        {
            // Achtunng hier nicht versehentlich proxy übergeben
            result = method.invoke(map, args);
        }
        catch (InvocationTargetException ex)
        {
            throw ex.getTargetException();
        }

        return result;
    }
    

	public static void main(final String[] args)
	{
		LoggedInUserService.INSTANCE.setLoggedInUser("ADMIN");
		
		var origValues = Map.of("Mike", 50, "Tim", 50, "Peter", 42);
		var modifiableMap = new HashMap<>(origValues);
	    //var restrictedMap = createRestricetdAccessMap(modifiableMap);
		var restrictedMap = createRestricetdAccessMapWithLogging(modifiableMap);
	    
	    restrictedMap.size();
	    restrictedMap.entrySet();
	    restrictedMap.put("LDM", 6);
	    restrictedMap.putAll(Map.of("ALF", 6, "Micha", 47));
	}

	private static <K,V> Map<K,V> createRestricetdAccessMap(Map<K,V> origValues)
	{		
	    final InvocationHandler handler = new AccessControlProxy<>(origValues);
	
	    final Class<?>[] proxyInterfaces = { Map.class };
	    return (Map<K, V>) Proxy.newProxyInstance(Map.class.getClassLoader(), 
	                                              proxyInterfaces, handler);	
	}
	
	// BONUS:

	private static <K,V> Map<K,V> createRestricetdAccessMapWithLogging(Map<K,V> origValues)
	{		
	    final InvocationHandler handler = new AccessControlProxy<>(origValues);
	
	    final Class<?>[] proxyInterfaces = { Map.class };
	    Map<K, V> map = (Map<K, V>)Proxy.newProxyInstance(Map.class.getClassLoader(), 
	                                              proxyInterfaces, handler);	
	    
	    InvocationHandler handler2 = new LoggingInvocationHandler(map);
	    return (Map<K, V>) Proxy.newProxyInstance(Map.class.getClassLoader(),
	                                              proxyInterfaces, handler2);

	}
}
