package z_solutions.part3.adapter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class TriangleAdapter extends BaseFigure
{
    private final Triangle triangle;

    TriangleAdapter(final Triangle triangle)
    {
        this.triangle = triangle;
    }

    @Override
    void draw()
    {
        triangle.drawTriangle();
    }

    @Override
    void fill()
    {
        triangle.fillTriangle();
    }
}
