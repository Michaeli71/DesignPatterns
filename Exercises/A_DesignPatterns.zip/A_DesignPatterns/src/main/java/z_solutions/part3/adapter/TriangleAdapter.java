package z_solutions.part3.adapter;

public class TriangleAdapter extends BaseFigure {
	private Triangle triangle;

	TriangleAdapter(Triangle triangle)
	{
		this.triangle = triangle;
	}

	@Override
	void draw() {
		triangle.drawTriangle();		
	}

	@Override
	void fill() {
		triangle.fillTriangle();			
	}
}
