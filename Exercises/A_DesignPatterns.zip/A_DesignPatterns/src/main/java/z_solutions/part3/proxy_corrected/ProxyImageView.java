package z_solutions.part3.proxy_corrected;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.concurrent.ForkJoinPool;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ProxyImageView extends JComponent implements ImageView
{
    private RealImageView realImage;
    private String    fileName;
    private boolean realObjectReady = false;
    private boolean initStarted = false;
    
    public ProxyImageView(String fileName)
    {
        this.fileName = fileName;        
        setPreferredSize(new Dimension(40, 40));
    }

    @Override
    public void paintComponent(Graphics g)
    {
        display(g);
    }
    
    @Override
    public void display(Graphics g)
    {        
        // while not finished initializing / loading
        if (!realObjectReady)
        {
            if (g != null)
            {
                final Dimension componentSize = getSize();
                g.setColor(Color.BLUE);
                g.fillRect(0, 0, componentSize.width, componentSize.height);
            }
                      
            // start
            if (!initStarted)
            {
                initStarted = true;
                // separat antriggern
                ForkJoinPool.commonPool().submit(() -> {
                        realImage = new RealImageView(fileName);                        
                        realObjectReady = true;
                        
                        SwingUtilities.invokeLater(() -> getParent().repaint());
                });
            }
        }
        else
        {
            realImage.display(g);
        }
    }
}