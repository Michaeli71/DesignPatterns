package z_solutions.part3.proxy_corrected;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RealImageView extends JComponent implements ImageView
{
    private String fileName;
    private Image image;
    
    public RealImageView(String fileName)
    {
        this.fileName = fileName;
        try
        {
            loadFromDisk(fileName);
            
            setPreferredSize(new Dimension(image.getWidth(null), image.getHeight(null)));
        }
        catch (IOException e)
        {
        }
    }

    @Override
    public void paintComponent(Graphics g)
    {
        display(g);
    }
    
    @Override
    public void display(Graphics g)
    {        
        g.drawImage(image, 0, 0, null);
    }

    private void loadFromDisk(String fileName) throws IOException
    {
        System.out.println("Loading " + fileName);
        
        final File imageFile = new File("src/main/resources", fileName);
        this.image = ImageIO.read(imageFile);
        
        // slow down to show effect
        try
        {
            Thread.sleep(2_000 * (int)(Math.random() * 5));
        }
        catch (InterruptedException e)
        {
        }
    }
}