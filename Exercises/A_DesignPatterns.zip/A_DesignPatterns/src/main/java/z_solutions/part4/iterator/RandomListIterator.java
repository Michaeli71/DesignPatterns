package z_solutions.part4.iterator;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RandomListIterator<E> implements Iterator<E>
{
    private int           currentPos = 0;

    private final List<E> original;

    private final int[]   shuffledIndexes;

    RandomListIterator(List<E> original)
    {
        this.original = original;

        // Index-Positionen shuffled erzeugen
        shuffledIndexes = IntStream.range(0, original.size()).toArray();
        shuffleArray(shuffledIndexes);
        //Arrays.shuffle(shuffledIndexes);
        // wieso gibt es das immer noch nicht im JDK?	
    }

    @Override
    public boolean hasNext()
    {
        return currentPos < original.size();
    }

    @Override
    public E next()
    {
        E currentElement = original.get(shuffledIndexes[currentPos]);

        currentPos++;

        return currentElement;
    }

    public static void main(String[] args)
    {

        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        Iterator<Integer> it = new RandomListIterator<>(values);
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
    }

    static void shuffleArray(int[] ar)
    {
        Random rnd = new Random();
        for (int i = ar.length - 1; i > 0; i--)
        {
            int index = rnd.nextInt(i + 1);
            // Simple swap
            int a = ar[index];
            ar[index] = ar[i];
            ar[i] = a;
        }
    }
}
