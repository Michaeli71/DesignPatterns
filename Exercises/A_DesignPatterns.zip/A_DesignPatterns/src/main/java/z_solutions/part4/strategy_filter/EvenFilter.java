package z_solutions.part4.strategy_filter;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

/** Filter auf gerade Zahlen */
public class EvenFilter implements FilterStrategy
{
    @Override
    public boolean acceptValue(final int value)
    {
        return value % 2 == 0;
    }

    @Override
    public String toString()
    {
        return "EvenFilter";
    }
}