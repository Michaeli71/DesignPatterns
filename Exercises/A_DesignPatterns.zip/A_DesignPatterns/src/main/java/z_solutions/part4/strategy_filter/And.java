package z_solutions.part4.strategy_filter;

import java.util.Objects;

import part4.entwurfsmuster.behavioral.strategy.FilterStrategy;

/**
 * Utility-Klasse zur Filterung mithilfe des Strategie-Musters <br>
 * Die Klasse <code>InverseFilter</code> erlaubt es beliebige Filterkriterien zu
 * invertieren. Sie ist gem�� dem Dekorierer-Muster realisiert.
 * 
 * @author Michael Inden
 * 
 *         Copyright 2011 by Michael Inden
 */
public final class And implements FilterStrategy 
{
	private final FilterStrategy filterStrategy1;
	private final FilterStrategy filterStrategy2;

	public And(final FilterStrategy filterStrategy1, final FilterStrategy filterStrategy2)
    {
        this.filterStrategy1 = 
        			  Objects.requireNonNull(filterStrategy1,
  				      "parameter 'filterStrategy1' must not be null!");
        
        this.filterStrategy2 = 
  			  Objects.requireNonNull(filterStrategy2,
			      "parameter 'filterStrategy2' must not be null!");
    }

	@Override
	public boolean acceptValue(final int value) {
		return filterStrategy1.acceptValue(value) && filterStrategy2.acceptValue(value);
	}

	@Override
	public String toString() {
		return "And";
	}
}