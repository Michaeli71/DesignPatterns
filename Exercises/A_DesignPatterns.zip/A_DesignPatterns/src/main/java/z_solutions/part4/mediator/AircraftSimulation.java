package z_solutions.part4.mediator;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class AircraftSimulation
{
    public static void main(String[] args)
    {
        Tower towerNY = new Tower("New York");
        Tower towerPH = new Tower("Philadelphia");

        Aircraft flight1 = Aircraft.create("Airbus A380", towerNY);
        Aircraft flight2 = Aircraft.create("Boeing 737", towerNY);
        Aircraft flight3 = Aircraft.create("FC04", towerPH);
        Aircraft flight4 = Aircraft.create("Boeing 747", towerNY);

        // 
        towerNY.notifyAircrafts("Stormy weather, danger of blizzards");
        towerPH.notifyAircrafts("change altitude + 1000");

        flight2.notifyTower("Mayday");
    }
}
