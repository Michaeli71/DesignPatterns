package z_erercises.part2.factory;

public class GameCharacterGenerator 
{
	public static void main(String[] args) {
		
		Ufo ufo = new Ufo();
		Bullet bullet = new Bullet();
		Player player = new Player();
	}

	
	static class Ufo
	{
		
	}

	static class Bullet
	{
		
	}

	static class Player
	{
		
	}

}
