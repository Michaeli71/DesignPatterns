package z_erercises.part2.builder;

public class BankAccountExample {

	public static void main(String[] args) 
	{	
		// soweit alles gut
		SimpleBankAccount account = new SimpleBankAccount(123L, "Bart", 100.00);
				
		//  Achtung: beim zweiten Mal ist der Zinssatz 200 %, gute Rendite :-)
		BankAccount normalAccount = new BankAccount(456L, "Marge", "Springfield", 100.00, 2.5);
		BankAccount anotherAccount = new BankAccount(789L, "Homer", null, 2.5, 200.00);  //Oops!
	}
}
