package z_erercises.part2.factory;

public class LowerBody implements Workout {

	@Override
	public void createWorkout() {
		System.out.println("Created Lower Body Workout that includes:");
		System.out.println("1. Stepper");
		System.out.println("2. Sit Ups");
		System.out.println("3. Legs");
	}
}