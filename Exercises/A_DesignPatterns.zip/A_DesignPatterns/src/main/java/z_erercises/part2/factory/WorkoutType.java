package z_erercises.part2.factory;

public enum WorkoutType 
{
	UPPERBODY, LOWERBODY, ENDURANCE;
}