package z_erercises.part2.factory;

public interface Workout {
	void createWorkout();
}