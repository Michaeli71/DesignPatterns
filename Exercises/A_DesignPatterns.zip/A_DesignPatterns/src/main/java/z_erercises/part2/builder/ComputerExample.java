package z_erercises.part2.builder;

public class ComputerExample 
{
	public static void main(String[] args) {
		
		Computer iMac2020 = new Computer("2 TB", "72 GB", true, true);

		Computer oldCompi = new Computer("500 GB", "2 GB", true, false);
		
        System.out.println(iMac2020);
        System.out.println(oldCompi);
	}
}
