package z_erercises.part2.builder;

public class SimpleBankAccount {

	private long accountNumber;
	private String owner;
	private double balance;

	public SimpleBankAccount(long accountNumber, String owner, double balance) {
		this.accountNumber = accountNumber;
		this.owner = owner;
		this.balance = balance;
	}

	// Getters and setters omitted for brevity.
}