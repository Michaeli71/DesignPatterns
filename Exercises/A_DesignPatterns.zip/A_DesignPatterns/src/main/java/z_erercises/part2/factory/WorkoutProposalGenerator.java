package z_erercises.part2.factory;

public class WorkoutProposalGenerator {
 
    public static void main(String[] args) {

    	// TODO
    }
}