package z_erercises.part2.factory;

public class UpperBody implements Workout {

	@Override
	public void createWorkout() {
		System.out.println("Created Upper Body Workout that includes:");
		System.out.println("1. Breast");
		System.out.println("2. Biceps");
		System.out.println("3. Triceps");
	}
}