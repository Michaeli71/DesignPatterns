package z_erercises.part2.builder;

public class Computer {

	// required parameters
	private String hdd;
	private String ram;

	// optional parameters
	private boolean isGraphicsCardEnabled;
	private boolean isBluetoothEnabled;

	public Computer(String hdd, String ram, boolean isGraphicsCardEnabled, boolean isBluetoothEnabled) {
		this.hdd = hdd;
		this.ram = ram;
		this.isGraphicsCardEnabled = isGraphicsCardEnabled;
		this.isBluetoothEnabled = isBluetoothEnabled;
	}

	public String getHDD() {
		return hdd;
	}

	public void setHDD(String hdd) {
		this.hdd = hdd;
	}

	public String getRAM() {
		return ram;
	}

	public void setRAM(String ram) {
		this.ram = ram;
	}

	public boolean isGraphicsCardEnabled() {
		return isGraphicsCardEnabled;
	}

	public void setGraphicsCardEnabled(boolean isGraphicsCardEnabled) {
		this.isGraphicsCardEnabled = isGraphicsCardEnabled;
	}

	public boolean isBluetoothEnabled() {
		return isBluetoothEnabled;
	}

	public void setBluetoothEnabled(boolean isBluetoothEnabled) {
		this.isBluetoothEnabled = isBluetoothEnabled;
	}

	@Override
	public String toString() {
		return "Computer [hdd=" + hdd + ", ram=" + ram + ", isGraphicsCardEnabled=" + isGraphicsCardEnabled
				+ ", isBluetoothEnabled=" + isBluetoothEnabled + "]";
	}
}