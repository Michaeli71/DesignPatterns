package z_erercises.part2.factory;

public class Endurance implements Workout {

	@Override
	public void createWorkout() {
		System.out.println("Created Lower Body Workout that includes:");
		System.out.println("1. Running");
		System.out.println("2. Skating");
		System.out.println("3. Cycling");
	}
}