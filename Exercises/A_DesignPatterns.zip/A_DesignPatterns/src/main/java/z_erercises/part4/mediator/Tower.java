package z_erercises.part4.mediator;

import java.util.ArrayList;
import java.util.List;

public class Tower {

	String name;
	List<Aircraft> aircrafts = new ArrayList<>();

	public Tower(String name) {
		this.name = name;

	}

	public void registerAircraft(Aircraft aircraft) {
		aircrafts.add(aircraft);
	}

	public void deregisterAircraft(Aircraft aircraft) 
	{
		aircrafts.remove(aircraft);
	}

	// TODO
}
