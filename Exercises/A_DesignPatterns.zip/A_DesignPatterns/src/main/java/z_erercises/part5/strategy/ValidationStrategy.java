package z_erercises.part5.strategy;

interface ValidationStrategy 
{
	public boolean validate(String input);
}