package z_erercises.part3.proxy_wrong;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ProxyImageView extends JComponent implements ImageView
{
    private RealImageView realImage;
    private String    fileName;

    public ProxyImageView(String fileName)
    {
        this.fileName = fileName;
        
        setPreferredSize(new Dimension(40, 40));
    }

    @Override
    public void paintComponent(Graphics g)
    {
        display(g);
    }
    
    @Override
    public void display(Graphics g)
    {
        if (realImage == null)
        {
            // Platzhalter malen
            if (g != null)
            {
                final Dimension componentSize = getSize();
                g.setColor(Color.BLUE);
                g.fillRect(0, 0, componentSize.width, componentSize.height);
            }
            
            // potenziell längerdauernd ... problematisch mit UI !!!
            realImage = new RealImageView(fileName);
        }
        else
        {
            realImage.display(g);
        }
    }
}