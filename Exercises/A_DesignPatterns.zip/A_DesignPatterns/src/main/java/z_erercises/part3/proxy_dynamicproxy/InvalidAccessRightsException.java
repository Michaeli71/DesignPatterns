package z_erercises.part3.proxy_dynamicproxy;

public class InvalidAccessRightsException extends RuntimeException {

	public InvalidAccessRightsException(String msg)
	{
		super(msg);
	}
}
