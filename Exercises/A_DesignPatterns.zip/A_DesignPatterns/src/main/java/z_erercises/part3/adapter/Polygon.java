package z_erercises.part3.adapter;

public class Polygon {

	void paintBorder() {
		System.out.println("paintBorder");
	}

	void filledWithPattern() {
		System.out.println("filledWithPattern");
	}
}