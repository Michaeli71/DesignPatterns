package z_erercises.part3.proxy_dynamicproxy;

public class LoggedInUserService {

	// könnte 
	public static LoggedInUserService INSTANCE = new LoggedInUserService();
	
	private String loggedInUser = "";

	public String getLoggedInUser() {
		return loggedInUser;
	}

	public void setLoggedInUser(String loggedInUser) {
		this.loggedInUser = loggedInUser;
	}
}
