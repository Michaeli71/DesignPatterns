package z_erercises.part3.composite;

import java.util.ArrayList;
import java.util.List;

public final class ComputerCompositeExample
{
	public static void main(final String[] args)
	{
		Computer computer = new Computer("MY-COMPI");
		computer.add(new ComputerPart("Keyboard", 65));
		computer.add(new ComputerPart("Monitor", 450));
		ComputerPart cpu = new ComputerPart("CPU", 550);
		computer.add(cpu);
		computer.add(new ComputerPart("Memory", 250));
		
		// Graphics Card
		// TODO
		
	    // TODO: printPrice
	}

    
    
    // TODO
    

    public static class ComputerPart  
    {
    	private final String name;
        private final int price;

        public ComputerPart(final String name, final int price)
        {
        	this.name = name;
            this.price = price;
        }

        public int calcPrice()
        {
            return price;
        }
    }

    public static class Computer
    {
    	private final String name;
    	private final List<ComputerPart> subComponents = new ArrayList<>();

        public Computer(final String name)
        {
        	this.name = name;
        }
		
        public void add(final ComputerPart computerComponent)
        {
        	subComponents.add(computerComponent);
        }
    }    
}
