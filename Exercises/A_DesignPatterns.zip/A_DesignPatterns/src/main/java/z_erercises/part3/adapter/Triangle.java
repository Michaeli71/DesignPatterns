package z_erercises.part3.adapter;

public class Triangle {

	void drawTriangle()
	{
		System.out.println("drawTriangle");
	}

	void fillTriangle()
	{
		System.out.println("fillTriangle");
	}
}
