package a_questions;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DecoratorExample {
	
	// interface vs abstract class
	interface BaseFunc
	{
		String convert(String input);
	}
	
	static class ToUpperFunc implements BaseFunc
	{
		@Override
		public String convert(String input) {
			return input.toUpperCase();
		}		
	}

	static class ToLowerFunc implements BaseFunc
	{
		@Override
		public String convert(String input) {
			return input.toLowerCase();
		}		
	}

	static class Highlighter implements BaseFunc
	{
		final BaseFunc originbalFunc;
		
		private int originalLength = 0;
		private boolean containsValidInfo = false;
		
		public Highlighter(BaseFunc originbalFunc) {
			this.originbalFunc = originbalFunc;
		}

		@Override
		public String convert(String input) {
			String convert = originbalFunc.convert(input);			
			originalLength = convert.length();
			
			containsValidInfo = convert.contains("secret");
			
			return ">>> " + convert + " <<<";
		}	
		
		public int getOriginalLength() {
			return originalLength;
		}
		
		public boolean containsValidInfo() {
			return containsValidInfo;
		}
	}
	
	
	
	public static void main(String[] args) {
				
		BaseFunc upper = new ToUpperFunc();
		System.out.println(upper.convert("INput"));
		
		BaseFunc lower = new ToLowerFunc();
		System.out.println(lower.convert("INPUT"));

		BaseFunc highlight = createSpecialHighlight(lower);
		System.out.println(highlight.convert("INPUT"));
		
		Highlighter highlighter = new Highlighter(lower);
		highlighter.convert("input");
		System.out.println(highlighter.getOriginalLength());
		System.out.println(highlighter.containsValidInfo());
		
		Highlighter highlighter2 = new Highlighter(lower);
		highlighter2.convert("This Is A SECRET Message");
		System.out.println(highlighter2.getOriginalLength());
		System.out.println(highlighter2.containsValidInfo());
	}
	
	
	// Factory/Create Method
	static BaseFunc createSpecialHighlight(BaseFunc originbalFunc)
	{
		return new Highlighter(new Highlighter(originbalFunc));
	}
	
}
