package a_questions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class IteratorSpecialCasesExample
{
    public static void main(String[] args)
    {
        List<String> names = new ArrayList<>(Arrays.asList("TIM", "Tom", "Peter", "James", "Jim", "Mike", "Jim"));
        System.out.println(names);

        // Variante 1: Problem aufeinanderfolgende
        // remove all starting with "J"   
        /*
        for (int i = 0; i < names.size(); i++)
        {
            String currentName = names.get(i);
            if (currentName.startsWith("J"))
            {
                // lösche
                // names.remove(i);
                names.remove(currentName);
            }
        }
        */
        
        Iterator<String> it = names.iterator();
        while (it.hasNext())
        {
            String currentName = it.next();
            if (currentName.startsWith("J"))
            {
                // lösche
                // names.remove(currentName);
                it.remove();
            }
        }
        
        // schöneres Design: Trenne Infromationsbeschaffung von Verarbeitung
        List<String> namesToDeleted = collectNamesToBeDeleted(names);
        System.out.println(namesToDeleted);

        names.removeAll(namesToDeleted);
        System.out.println(names);
        
        
        List<String> namesWithT = collectNames(names, str -> str.startsWith("T"));
        System.out.println(namesWithT);
    }

    private static List<String> collectNamesToBeDeletedOld(List<String> names)
    {
        List<String> namesToDelete = new ArrayList<>();
        Iterator<String> it = names.iterator();
        while (it.hasNext())
        {
            String currentName = it.next();
            if (currentName.startsWith("J"))
            {
                namesToDelete.add(currentName);
            }
        }
        return namesToDelete;
    }
    
    private static List<String> collectNamesToBeDeleted(List<String> names)
    {        
        return collectNames(names, str -> str.startsWith("J"));
    }

    private static List<String> collectNames(List<String> names, Predicate<String> filter)
    {
        List<String> namesToDelete = new ArrayList<>();
        Iterator<String> it = names.iterator();
        while (it.hasNext())
        {
            String currentName = it.next();
            if (filter.test(currentName))
            {
                namesToDelete.add(currentName);
            }
        }
        return namesToDelete;
    }
}
