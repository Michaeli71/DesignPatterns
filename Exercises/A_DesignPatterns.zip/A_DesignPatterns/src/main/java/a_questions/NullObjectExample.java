package a_questions;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class NullObjectExample {

	public static void main(String[] args) {
		
		List<String> result = findSpecial("ABC");

		// => View
		// --
		// --
		// "Keine Einträge"
		
		// AKTION
		
		//
		List<String> modifiableResult = new ArrayList<>(result);
		result.add("NEW DATA");
		
	}

	static List<String> findSpecial(String info)
	{
		// ...
		
		//return Collections.emptyList();
		return new ArrayList<>();
	}
	
	static Optional<List<String>> findSpecial2(String info)
	{
		// ...
		boolean found = true;
		if (found)
			return Optional.of(new ArrayList<>()); //  ..."
		
		return Optional.empty();
	}
}
