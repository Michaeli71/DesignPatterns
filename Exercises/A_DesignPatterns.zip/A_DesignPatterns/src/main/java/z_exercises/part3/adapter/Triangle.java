package z_exercises.part3.adapter;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Triangle
{

    void drawTriangle()
    {
        System.out.println("drawTriangle");
    }

    void fillTriangle()
    {
        System.out.println("fillTriangle");
    }
}
