package z_exercises.part5.strategy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
interface ValidationStrategy
{
    public boolean validate(String input);
}