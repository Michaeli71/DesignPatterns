package z_exercises.part5.strategy;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ValidationExample
{
    public static void main(String[] args)
    {
        // old school
        Validator v1 = new Validator(new IsNumeric());
        System.out.println(v1.validate("12345"));

        Validator v2 = new Validator(new IsAllLowerCase());
        System.out.println(v2.validate("valid"));

        // with lambdas
        // TODO
    }
}
