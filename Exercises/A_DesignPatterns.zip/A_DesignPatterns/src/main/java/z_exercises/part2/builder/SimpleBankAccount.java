package z_exercises.part2.builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class SimpleBankAccount
{
    private final long   accountNumber;

    private final String owner;

    private double balance;

    public SimpleBankAccount(long accountNumber, String owner, double balance)
    {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = balance;
    }
}