package z_exercises.part2.factory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LowerBody implements Workout
{
    @Override
    public void createWorkout()
    {
        System.out.println("Created Lower Body Workout that includes:");
        System.out.println("1. Stepper");
        System.out.println("2. Sit Ups");
        System.out.println("3. Legs");
    }
}