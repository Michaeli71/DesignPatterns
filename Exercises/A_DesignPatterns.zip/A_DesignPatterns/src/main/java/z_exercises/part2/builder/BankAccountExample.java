package z_exercises.part2.builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class BankAccountExample
{
    public static void main(String[] args)
    {
        // soweit alles gut
        SimpleBankAccount account = new SimpleBankAccount(123L, "Peter", 100.00);

        //  Achtung: beim zweiten Mal ist der Zinssatz 200 %, gute Rendite :-)
        BankAccount normalAccount = new BankAccount(456L, "James", "Zurich", 100.00, 2.5);
        BankAccount anotherAccount = new BankAccount(789L, "Michael", null, 2.5, 200.00); //Oops!
    }
}
