package z_exercises.part2.builder;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class BankAccount
{
    private final long   accountNumber;

    private final String owner;

    private String branch;

    private double balance;

    private double interestRate;

    public BankAccount(long accountNumber, String owner, String branch, double balance, double interestRate)
    {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.branch = branch;
        this.balance = balance;
        this.interestRate = interestRate;
    }
}
