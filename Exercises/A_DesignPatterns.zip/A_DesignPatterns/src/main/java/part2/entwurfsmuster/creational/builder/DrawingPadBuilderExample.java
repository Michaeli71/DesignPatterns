package part2.entwurfsmuster.creational.builder;

import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DrawingPadBuilderExample
{
    static class DrawingPad
    {
        DrawingPad(final String title, final boolean runAsApplet, final Object applet, final Object appParams, List<String> additionalParameters)
        {
        }
    }

    static class DrawingPadBuilder
    {
        String title;
        boolean asApplet;
        boolean asApplication;
        Object applet;
        Object appParams;
        List<String> additionalParameters;
        
        public DrawingPadBuilder asApplet()
        {
            asApplet = true;
            asApplication = false;
            appParams = null;
            return this;
        }
        
        public DrawingPadBuilder asApplication()
        {
            asApplet = false;
            asApplication = true;
            applet = null;
            return this;
        }
        
        public DrawingPadBuilder withAppParams(Object appParams)
        {
            if (!asApplication)
                throw new IllegalStateException();
            
            this.appParams = appParams;
            
            return this;
        }
        
        public DrawingPadBuilder withTitle(String title)
        {
            this.title = title;
            return this;
        }
        
        DrawingPad build()
        {
            return new DrawingPad(title, asApplet, applet, appParams, additionalParameters);
        }
    }
    
    
    public static void main(String[] args)
    {
        new DrawingPadBuilder().asApplet().withTitle("Veraltetes Applet"); 
        //.withAppParams("IMPORTANT PARAM");
        new DrawingPad("Veraltetes Applet", true, null, null, null);
        
        new DrawingPadBuilder().asApplication().withTitle("Schöne Applikation").withAppParams("IMPORTANT PARAM");
        new DrawingPad("Schöne Applikation", false, null, "IMPORTANT PARAM", null);
        
    }
}
