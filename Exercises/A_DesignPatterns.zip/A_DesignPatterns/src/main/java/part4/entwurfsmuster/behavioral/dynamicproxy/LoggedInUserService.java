package part4.entwurfsmuster.behavioral.dynamicproxy;

public class LoggedInUserService {

	// könnte 
	public static LoggedInUserService INSTANCE = new LoggedInUserService();
	
	private String loggedInUser = "";

	public String getLoggedInUser() {
		return loggedInUser;
	}

	public void setLoggedInUser(String loggedInUser) {
		this.loggedInUser = loggedInUser;
	}
}
