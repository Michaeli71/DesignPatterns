package part4.entwurfsmuster.behavioral;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public final class NullIterator<E> implements Iterator<E> 
{
	@Override
	public boolean hasNext() 
	{
		return false;
	}

	@Override
	public E next() 
	{
		throw new NoSuchElementException("NullIterator provides no elements!");
	}

	@Override
	public void remove() 
	{
		throw new UnsupportedOperationException("NullIterator does not " + "implement remove()!");
	}
}