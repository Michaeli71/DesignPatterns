package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

class Number implements Expression {
	private int number = 0;

	public Number(final int number) {
		this.number = number;
	}

	@Override
	public int interpret(final Map<String, Integer> variables) {
		return number;
	}
}