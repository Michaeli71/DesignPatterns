package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/* Erweiterung 2 */
class SqrFunction implements Expression {
	Expression operand = null;

    public SqrFunction(final Expression operand)  {
        this.operand = operand;
    }

    @Override
    public int interpret(final Map<String,Integer> variables) {
        int tmp = operand.interpret(variables);
        return tmp*tmp;
    }
}