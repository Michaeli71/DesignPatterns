package part4.entwurfsmuster.behavioral;

import java.util.ArrayList;
import java.util.List;

public class VisitorPattern
{
    public static void main(final String[] args)
    {
        final List<Visitable> visitableElements = new ArrayList<>();
        visitableElements.add(new Book("Java 8", 10, 24.90));
        visitableElements.add(new Meal(5, 15.0));
        visitableElements.add(new Car(2, 1000.0));

        final BillingVisitor billingVisitor = new BillingVisitor();
        billingVisitor.process(visitableElements);

        final OfferVisitor offerVisitor = new OfferVisitor();
        offerVisitor.process(visitableElements);

        final XMLVisitor xmlVisitor = new XMLVisitor();
        xmlVisitor.process(visitableElements);

        System.out.println("Total value:\n" + billingVisitor.totalPrice);
        System.out.println("\nAs Offer:\n" + offerVisitor.offer);
        System.out.println("\nAs XML:\n" + xmlVisitor.xmlRepresentation);
    }

    interface Visitor
    {
        void visit(final Book book);

        void visit(final Meal meal);

        void visit(final Car car);
    }

    // Element
    interface Visitable
    {
        public void accept(Visitor visitor);
    }

    static class OfferVisitor implements Visitor
    {
        private final StringBuilder offer = new StringBuilder("We offer the following products and prices:\n");

        protected void process(final List<Visitable> visitableElements)
        {
            for (final Visitable visitableElement : visitableElements)
            {
                visitableElement.accept(this);
            }
        }

        @Override
        public void visit(final Book book)
        {
            offer.append("- Book: " + book.price + "€, Available: " + book.quantity + "\n");
        }

        @Override
        public void visit(final Meal meal)
        {
            offer.append("- Meal: " + meal.price + "€, Available: " + meal.quantity + "\n");
        }

        @Override
        public void visit(final Car car)
        {
            offer.append("- Car: " + car.price + "€, Available: " + car.quantity + "\n");
        }
    }

    static class BillingVisitor implements Visitor
    {
        private double totalPrice = 0.0;

        protected void process(final List<Visitable> visitableElements)
        {
            for (final Visitable visitableElement : visitableElements)
            {
                visitableElement.accept(this);
            }
        }

        @Override
        public void visit(final Book book)
        {
            totalPrice += (book.quantity * book.price);
        }

        @Override
        public void visit(final Meal meal)
        {
            totalPrice += (meal.quantity * meal.price);
        }

        @Override
        public void visit(final Car car)
        {
            totalPrice += (car.quantity * car.price);
        }
    }

    static class Book implements Visitable
    {
        private final String title;

        private final double quantity;

        private final double price;

        public Book(final String title, final double quantity, final double price)
        {
            this.title = title;
            this.quantity = quantity;
            this.price = price;
        }

        @Override
        public void accept(final Visitor visitor)
        {
            visitor.visit(this);
        }
    }

    static class Meal implements Visitable
    {
        private final double quantity;

        private final double price;

        public Meal(final double quantity, final double price)
        {
            this.quantity = quantity;
            this.price = price;
        }

        @Override
        public void accept(final Visitor visitor)
        {
            visitor.visit(this);
        }
    }

    static class Car implements Visitable
    {
        private final double quantity;

        private final double price;

        public Car(final double quantity, final double price)
        {
            this.quantity = quantity;
            this.price = price;
        }

        @Override
        public void accept(final Visitor visitor)
        {
            visitor.visit(this);
        }
    }

    static class XMLVisitor implements Visitor
    {
        private final StringBuilder xmlRepresentation = new StringBuilder("<xml>\n");

        protected void process(final List<Visitable> visitableElements)
        {
            for (final Visitable visitableElement : visitableElements)
            {
                visitableElement.accept(this);
            }

            xmlRepresentation.append("</xml>");
        }

        @Override
        public void visit(final Book book)
        {
            xmlRepresentation.append(tag("book", tag("price", book.price) + tag("isbn", book.title) ) + "\n");
        }

        @Override
        public void visit(final Meal meal)
        {
            xmlRepresentation.append("<meal><price>" + meal.price + "</price></meal>" + "\n");
        }

        @Override
        public void visit(final Car project)
        {
            xmlRepresentation.append("<car><price>" + project.price + "</price></car>" + "\n");
        }
        
        public String tag(final String tagName, final Object value)
        {
            return "<" + tagName + ">" + value + "/<" + tagName + ">";
        }
    }
}