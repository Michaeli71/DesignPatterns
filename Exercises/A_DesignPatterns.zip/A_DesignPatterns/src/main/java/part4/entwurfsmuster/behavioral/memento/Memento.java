package part4.entwurfsmuster.behavioral.memento;

import java.time.LocalDate;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Memento {  
      
    private final String info ;
    private final LocalDate date;  
    private final int value;
    
    public Memento(String info, LocalDate date, int value)
    {
        this.info = info;
        this.date = date;
        this.value = value;
    }

    public String getInfo()
    {
        return info;
    }

    public LocalDate getDate()
    {
        return date;
    }

    public int getValue()
    {
        return value;
    }      
}

// Java 15:
//record MementoWithRecord(String info, LocalDate date, int value) {}