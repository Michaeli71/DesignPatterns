package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

class Minus implements Expression {
	private Expression leftOperand = null;
	private Expression rightOperand = null;

	public Minus(final Expression left, final Expression right) {
		leftOperand = left;
		rightOperand = right;
	}

	@Override
	public int interpret(final Map<String, Integer> variables) {
		return leftOperand.interpret(variables) - rightOperand.interpret(variables);
	}
}