package part4.entwurfsmuster.behavioral.dynamicproxy;

import java.util.concurrent.TimeUnit;

public class ServicePerformanceProxy implements IService
{
	private final IService service;

	ServicePerformanceProxy(final IService service) 
	{
		this.service = service;
	}

	@Override
	public String calculateSomething(int value) 
	{
		final long startTime = System.nanoTime();

		final String result = service.calculateSomething(value);

		printExecTime("calculateSomething", System.nanoTime() - startTime);

		return result;
	}

	@Override
	public void doSomething() 
	{
		final long startTime = System.nanoTime();

		service.doSomething();

		printExecTime("doSomething", System.nanoTime() - startTime);
	}

    private void printExecTime(final String methodName, final long duration)
    {
        System.out.println("Method call of '" + methodName + "' took: " + 
                           TimeUnit.NANOSECONDS.toMillis(duration) + " ms");
    }
}