package part4.entwurfsmuster.behavioral.dynamicproxy;

public class InvalidAccessRightsException extends RuntimeException {

	public InvalidAccessRightsException(String msg)
	{
		super(msg);
	}
}
