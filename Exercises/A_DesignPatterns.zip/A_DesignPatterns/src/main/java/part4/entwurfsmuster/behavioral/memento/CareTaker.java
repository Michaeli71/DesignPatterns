package part4.entwurfsmuster.behavioral.memento;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class CareTaker
{
    final List<Memento> storedStates = new ArrayList<>();
    
    void saveState(Memento currentSate)
    {
        storedStates.add(currentSate);
    }
    
    Memento restoreLast()
    {
        return restore(storedStates.size() - 1);
    }

    Memento restore(int index)
    {
        return storedStates.remove(index);
    }
}
