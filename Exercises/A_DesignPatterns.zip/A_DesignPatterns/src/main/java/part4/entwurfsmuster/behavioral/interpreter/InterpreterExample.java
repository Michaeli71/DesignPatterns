package part4.entwurfsmuster.behavioral.interpreter;

import java.util.HashMap;

public class InterpreterExample {
	/**
	 * Test method for the interpreter
	 * 
	 * @param arguments
	 */
	public static void main(final String[] arguments) {
		final String expression = "w x z - + -2 +";
		final HashMap<String, Integer> variables = new HashMap<>();

		variables.put("w", 5);
		variables.put("x", 33);
		variables.put("z", 10);

		final Expression tree = Parser.parseExpression(expression);

		System.out.println(tree.interpret(variables));

		// UPN
		final Expression tree2 = Parser.parseExpression("7 5 +");

		System.out.println(tree2.interpret(variables));

		// Erweiterung 1
		final Expression tree3 = Parser.parseExpression("7 5 *");

		System.out.println(tree3.interpret(variables));

		// Erweiterung 2
		final Expression tree4 = Parser.parseExpression("7 ** 5 sqr +");

		System.out.println(tree4.interpret(variables));
	}
}