package part4.entwurfsmuster.behavioral.dynamicproxy;

public interface IService 
{
	public void doSomething();
	public String calculateSomething(int value);
}