package part4.entwurfsmuster.behavioral.strategy;

public interface FilterStrategy {
	public abstract boolean acceptValue(final int value);
}