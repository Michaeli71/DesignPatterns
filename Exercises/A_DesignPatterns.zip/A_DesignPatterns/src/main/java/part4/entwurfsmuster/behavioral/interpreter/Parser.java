package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Stack;
import java.util.regex.Pattern;

class Parser {

	static public Expression parseExpression(final String expression) {
		Expression syntaxTree = null;
		Pattern numberPattern = Pattern.compile("[+-]?\\d+");

		Stack<Expression> expressionStack = new Stack<>();

		for (String token : expression.split(" ")) {
			if (token.equals("+")) {
				Expression subExpression = new Plus(expressionStack.pop(), expressionStack.pop());
				expressionStack.push(subExpression);
			} else if (token.equals("-")) {
				Expression subExpression = new Minus(expressionStack.pop(), expressionStack.pop());
				expressionStack.push(subExpression);
			}
			else if (token.equals("*")) {
				Expression subExpression = new Mult(expressionStack.pop(), expressionStack.pop());
				expressionStack.push(subExpression);
			}
			
			/* Erweiterung 2 */
			// 
			else if (token.equals("sqr") || token.equals("**")) {
				Expression subExpression = new SqrFunction(expressionStack.pop());
				expressionStack.push(subExpression);
			} else if (numberPattern.matcher(token).matches()) {
				expressionStack.push(new Number(Integer.parseInt(token.trim())));
			} else
				expressionStack.push(new Variable(token));
		}

		syntaxTree = expressionStack.pop();

		return syntaxTree;
	}
	
	// Live Coding 
}