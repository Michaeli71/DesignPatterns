package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

class Plus implements Expression {
	private Expression leftOperand = null;
	private Expression rightOperand = null;

	public Plus(final Expression left, final Expression right) {
		leftOperand = left;
		rightOperand = right;
	}

	@Override
	public int interpret(final Map<String, Integer> variables) {
		return leftOperand.interpret(variables) + rightOperand.interpret(variables);
	}

	@Override
	public String toString() {
		return leftOperand.toString() + " + " + rightOperand.toString();
	}
}