package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/* Erweiterung 1 */
class Mult implements Expression {
	private Expression leftOperand = null;
	private Expression rightOperand = null;

	public Mult(final Expression left, final Expression right) {
		leftOperand = left;
		rightOperand = right;
	}

	@Override
	public int interpret(final Map<String, Integer> variables) {
		return leftOperand.interpret(variables) * rightOperand.interpret(variables);
	}

	@Override
	public String toString() {
		return leftOperand.toString() + " * " + rightOperand.toString();
	}
}