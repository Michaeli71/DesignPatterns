package part4.entwurfsmuster.behavioral.interpreter;

public class ExpressionUtils {

	public static boolean isBinaryOperator(String s) {
		if (s.equals("+") || s.equals("-") || s.equals("*"))
			return true;
		else
			return false;
	}

	public static boolean isUnaryOperator(String s) {
		if (s.equals("sqr") || s.equals("**"))
			return true;
		else
			return false;
	}
	
	public static Expression getOperator(String s, Expression left, Expression right) {
		switch (s) {
		case "+":
			return new Plus(left, right);
		case "-":
			return new Minus(left, right);
		case "*":
			return new Mult(left, right);
		}
		return null;
	}

}