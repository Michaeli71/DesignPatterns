package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

class Variable implements Expression {
	private String name;

	public Variable(final String name) {
		this.name = name;
	}

	@Override
	public int interpret(final Map<String, Integer> variables) {
		return variables.get(name);
	}
}
