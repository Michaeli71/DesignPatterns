package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class Variable implements Expression
{
    private final String name;

    public Variable(final String name)
    {
        this.name = name;
    }

    @Override
    public int interpret(final Map<String, Integer> variables)
    {
        return variables.get(name);
    }
}
