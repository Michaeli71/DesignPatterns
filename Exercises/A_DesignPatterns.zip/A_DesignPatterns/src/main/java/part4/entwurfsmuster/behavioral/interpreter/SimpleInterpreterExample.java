package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;
import java.util.Stack;

// Hier ohne Variablen
public class SimpleInterpreterExample {

	public static void main(String[] args) {

		// String tokenString = "7 3 - 2 ** 1 + *";
		String tokenString = "7 3 - 2 1 + *";
		Stack<Expression> stack = new Stack<>();
		String[] tokenArray = tokenString.split(" ");
		for (String s : tokenArray) {

			if (ExpressionUtils.isBinaryOperator(s)) {
				Expression operator = ExpressionUtils.getOperator(s, stack.pop(), stack.pop());

				int result = operator.interpret(Map.of());
				stack.push(new Number(result));
			} else if (ExpressionUtils.isUnaryOperator(s)) {
				Expression operator = new SqrFunction(stack.pop());
				int result = operator.interpret(Map.of());
				stack.push(new Number(result));
			} else {
				Expression i = new Number(Integer.parseInt(s));
				stack.push(i);
			}
		}
		System.out.println("( " + tokenString + " ): " + stack.pop().interpret(Map.of()));

	}

}