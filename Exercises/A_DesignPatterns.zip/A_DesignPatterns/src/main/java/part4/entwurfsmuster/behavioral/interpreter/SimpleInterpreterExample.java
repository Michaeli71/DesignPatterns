package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;
import java.util.Stack;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
// Hier ohne Variablen
public class SimpleInterpreterExample
{
    public static void main(String[] args)
    {
        String tokenString = "7 ** 2 +";
        //String tokenString = "7 3 - 2 1 + *";
        Stack<Expression> stack = new Stack<>();
        String[] tokenArray = tokenString.split(" ");
        
        for (String token : tokenArray)
        {
            if (ExpressionUtils.isBinaryOperator(token))
            {
                Expression operator = ExpressionUtils.getBinaryOperator(token, stack.pop(), stack.pop());

                int result = operator.interpret(Map.of());
                stack.push(new SimpleNumber(result));

            }
            else if (token.equals("sqr") || token.equals("**"))
            {
                Expression operator = new SqrFunction(stack.pop());
                
                int result = operator.interpret(Map.of());
                stack.push(new SimpleNumber(result));
            }
            else
            {
                Expression expr = new SimpleNumber(Integer.parseInt(token));
                stack.push(expr);
            }
        }
        
        System.out.println("( " + tokenString + " ): " + stack.pop().interpret(Map.of()));
    }
}