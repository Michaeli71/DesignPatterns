package part4.entwurfsmuster.behavioral.observer;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public interface SelectionChangeListener
{
    void selectionChanged(Integer selectedIndex);
}
