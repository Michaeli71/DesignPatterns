package part4.entwurfsmuster.behavioral.observer;

import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DataModel 
{
    String info;
    int value;
    List<String> names;
    int selectedNameIdx = -1;
 
    // ChangeListener
    SelectionChangeListener selectionChangeListener = new NoOpListener();
    DataChangeListener dataChangeListener = new NoOpListener();
    
    public String getInfo()
    {
        return info;
    }
    public void setInfo(String info)
    {
        this.info = info;
        dataChangeListener.dataChanged(info);
    }
    public int getValue()
    {
        return value;
    }
    public void setValue(int value)
    {
        this.value = value;
        dataChangeListener.dataChanged(value);
    }
    public List<String> getNames()
    {
        return names;
    }
    public void setNames(List<String> names)
    {
        this.names = names;
        dataChangeListener.dataChanged(value);
    }
    
    public void selectIndex(int newSelectedIndex)
    {        
        if (selectedNameIdx != newSelectedIndex)
        {
            selectedNameIdx = newSelectedIndex;    
            selectionChangeListener.selectionChanged(newSelectedIndex);
        }
    }
    
    //
    
    public SelectionChangeListener getSelectionChangeListener()
    {
        return selectionChangeListener;
    }
    public void registerSelectionChangeListener(SelectionChangeListener selectionChangeListener)
    {
        this.selectionChangeListener = selectionChangeListener;
    }

    public DataChangeListener getDataChangeListener()
    {
        return dataChangeListener;
    }
    public void registerDataChangeListener(DataChangeListener dataChangeListener)
    {
        this.dataChangeListener = dataChangeListener;
    }    
    public void deregisterDataChangeListener(DataChangeListener dataChangeListener)
    {
        this.dataChangeListener = getNoOpListener();
    }
    public void deregisterSelectionChangeListener(SelectionChangeListener selectionChangeListener)
    {
        this.selectionChangeListener = getNoOpListener();
    }
    
    // Simple Flyweight, statt immer neue Objekte, eins reusen
    static NoOpListener noOpListener = new NoOpListener();
    static NoOpListener getNoOpListener()
    {
        return noOpListener;
    }
}
