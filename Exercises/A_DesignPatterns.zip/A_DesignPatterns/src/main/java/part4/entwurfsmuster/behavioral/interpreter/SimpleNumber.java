package part4.entwurfsmuster.behavioral.interpreter;

import java.util.Map;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class SimpleNumber implements Expression
{
    private final int value;

    public SimpleNumber(final int value)
    {
        this.value = value;
    }

    @Override
    public int interpret(final Map<String, Integer> variables)
    {
        return value;
    }
}