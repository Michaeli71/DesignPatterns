package part3.entwurfsmuster.structural;

import java.util.Comparator;
import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public final class ReverseComparator<T> implements Comparator<T> 
{
	private final Comparator<T> originalComparator;

	public ReverseComparator(final Comparator<T> originalComparator) 
	{
		this.originalComparator = Objects.requireNonNull(originalComparator, 
				                  "originalComparator must not be null!");
	}

	@Override
	public int compare(final T o1, final T o2) 
	{
		return originalComparator.compare(o2, o1);
	}
}