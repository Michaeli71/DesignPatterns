package part3.entwurfsmuster.structural.adapter;

import java.util.Iterator;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ArrayIteratorAdapter<T> implements Iterator<T> 
{
	int currentPosition;
	final T[] adaptee;

	public ArrayIteratorAdapter(final T[] adaptee) {
		this.adaptee = adaptee;
		this.currentPosition = 0;
	}

	@Override
	public boolean hasNext() {
		return currentPosition < adaptee.length;
	}

	@Override
	public T next()
	{
		final T next = adaptee[currentPosition];
		currentPosition++;
		return next;
	}

	// Da wir nur einen Wrapper darstellen, dürfen und // wollen wir nicht
	// verändern!!!
	@Override
	public void remove() 
	{
		throw new UnsupportedOperationException("Adapter does not " +                    
                                                " implement remove!");
	}
	
	public static void main(String[] args)
    {
        String[] names = { "Mike", "Andy", "Tim", "Tom", "Marco", "Nils" };

        // List -> ListModel
        final Iterator<String> it = new ArrayIteratorAdapter<>(names);
        while (it.hasNext())
        {
        	System.out.println(it.next());
        }
    }
}
