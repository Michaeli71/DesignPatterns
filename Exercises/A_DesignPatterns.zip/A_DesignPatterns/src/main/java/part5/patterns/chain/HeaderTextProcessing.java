package part5.patterns.chain;

public class HeaderTextProcessing extends ProcessingObject<String> {
	@Override
	public String handleWork(String text) {
		return "Hey workshop participants: " + text;
	}
}
