package part5.patterns.chain;

public class SpellCheckerProcessing extends ProcessingObject<String> {
	public String handleWork(String text) {
		return text.replaceAll("labda", "lambda");
	}
}