package part5.patterns.chain.modernized;

import java.util.function.Function;
import java.util.function.UnaryOperator;

import part5.patterns.chain.HeaderTextProcessing;

public class NewStyleChainExample {
	public static void main(String[] args) {

		// First processing object
		//UnaryOperator<String> headerProcessing = (String text) -> "Hey workshop partiipants: " + text;
		UnaryOperator<String> headerProcessing = (String text) -> new HeaderTextProcessing().handleWork(text);

		// Second processing object
		UnaryOperator<String> spellCheckerProcessing = (String text) -> text.replaceAll("labda", "lambda");
		
		// Third processing object
		UnaryOperator<String> converterProcessing = (String text) -> text.replaceAll("beautiful", "cool");

		// Compose the two functions resulting in a chain of operations.
		Function<String, String> pipeline = headerProcessing.andThen(spellCheckerProcessing).andThen(converterProcessing);
		String result2 = pipeline.apply("labdas are really beautiful?!!");
		System.out.println(result2);
	}
}
