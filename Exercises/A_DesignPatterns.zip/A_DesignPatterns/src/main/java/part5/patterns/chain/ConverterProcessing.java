package part5.patterns.chain;

public class ConverterProcessing extends ProcessingObject<String> {
	@Override
	public String handleWork(String text) {
		return text.replaceAll("beautiful", "cool");
	}
}