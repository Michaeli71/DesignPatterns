package part5.patterns.factory.modernized;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class FactoryMethod_Modernized
{
    static class WebDriver
    {
    }

    static class ChromeDriver extends WebDriver
    {
    }

    static class FirefoxDriver extends WebDriver
    {
    }

    public enum DriverType {
        CHROME, FIREFOX, SAFARI, IE;
    }

    //chrome driver supplier
    private static final Supplier<WebDriver> chromeDriverSupplier  = () -> {
                                                                       System.setProperty("webdriver.chrome.driver",
                                                                                          "/path/to/chromedriver");
                                                                       return new ChromeDriver();
                                                                   };

    //firefox driver supplier
    private static final Supplier<WebDriver> firefoxDriverSupplier = () -> {
                                                                       System.setProperty("webdriver.gecko.driver",
                                                                                          "/Users/username/Downloads/geckodriver");
                                                                       return new FirefoxDriver();
                                                                   };

    // Factory Method, Variante mit Optional später
    public static final WebDriver getDriver(DriverType type)
    {
        if (DriverType.CHROME == type)
            return chromeDriverSupplier.get();
        if (DriverType.FIREFOX == type)
            return firefoxDriverSupplier.get();

        throw new IllegalArgumentException("Unsupported driver type");
    }

    
    public static class DriverFactory
    {
        private static final Map<DriverType, Supplier<WebDriver>> driverMap = new HashMap<>();

        //add all the drivers into a map
        static
        {
            driverMap.put(DriverType.CHROME, chromeDriverSupplier);
            driverMap.put(DriverType.FIREFOX, firefoxDriverSupplier);
        }

        public static final Optional<WebDriver> getDriver(DriverType type)
        {
            return Optional.ofNullable(driverMap.get(type).get());
        }
    }
}
