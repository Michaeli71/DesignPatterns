package part5.patterns.templatemethod;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public abstract class TemplateMethodExample
{
    public final void templateMethod()
    {
        first();
        step1();
        step2();
        step3();
    
        hook();
    
        last();
    
    }
    
    abstract protected void first();
    
    abstract protected void last();
    
    void step1()
    {
        System.out.println("step1");
    }

    void step2()
    {
        System.out.println("step2");
    }

    void step3()
    {
        System.out.println("step3");
    }

    protected void hook()
    {
    }

    public static void main(String[] args)
    {
        TemplateMethodExample tme = new TemplateMethodExample()
        {
            @Override
            protected void first()
            {
                System.out.println("FIRST");
            }
        
            @Override
            protected void last()
            {
                System.out.println("LAST");
            }
        };
        tme.templateMethod();
    }
}
