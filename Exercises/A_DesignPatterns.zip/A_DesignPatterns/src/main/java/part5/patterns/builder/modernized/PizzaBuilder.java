package part5.patterns.builder.modernized;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class PizzaBuilder
{
    enum Size {
        SMALL, MEDIUM, LARGE
    }

    public boolean mitSalami         = false;

    public boolean mitExtraSardellen = false;

    public String  info              = "";

    public Size    size              = Size.MEDIUM;

    public PizzaBuilder with(final Consumer<PizzaBuilder> builderFunction)
    {
        builderFunction.accept(this);
        return this;
    }

    public Pizza build()
    {
        return new Pizza(this);
    }

    public static void main(String[] args)
    {
        // Problem: Lesbarkeit, direkter Zugriff auf Attribute
        // keine Möglchkeit zum Eingriff für optionale Attribute
        Pizza pizza = new PizzaBuilder().with($ -> $.info = "Kein Mais").with($ -> $.size = Size.MEDIUM)
                        .with($ -> $.mitSalami = true).build();

        System.out.println(pizza);
    }

    public static final class Pizza
    {
        private static final int ANZAHL_SALAMI          = 5;

        private static final int ANZAHL_EXTRA_SARDELLEN = 7;

        List<Salami>             salami                 = null;

        List<Sardelle>           sardellen              = null;

        String                   info                   = null;

        Size                     size                   = null;

        Pizza(final PizzaBuilder buildOptions)
        {
            // Erzeuge eine boolesche Option
            salami = new LinkedList<>();
            if (buildOptions.mitSalami)
            {
                for (int i = 0; i < ANZAHL_SALAMI; i++)
                {
                    salami.add(new Salami());
                }
            }

            // Erzeuge die gew�nschte Anzahl an Sardellen
            sardellen = new LinkedList<>();
            if (buildOptions.mitExtraSardellen)
            {
                for (int i = 0; i < ANZAHL_EXTRA_SARDELLEN; i++)
                {
                    sardellen.add(new Sardelle());
                }
            }

            // Normale Wertzuweisungen
            info = buildOptions.info;
            size = buildOptions.size;
        }

        @Override
        public String toString()
        {
            return this.getClass().getSimpleName() + " Attribute: " + createAttributeInfo("info", info) + " / "
                   + createAttributeInfo("size", size) + " / " + createAttributeInfo("Salami", salami) + " / "
                   + createAttributeInfo("Sardellen", sardellen);
        }

        // toString-Hilfe 
        private String createAttributeInfo(final String attributeName, final Object attribute)
        {
            return attributeName + ": '" + (attribute != null ? attribute : "-") + "'";
        }
    }

    // Options to choose
    public static final class Salami
    {
        @Override
        public String toString()
        {
            return this.getClass().getSimpleName();
        }
    }

    public static final class Sardelle
    {
        @Override
        public String toString()
        {
            return this.getClass().getSimpleName();
        }
    }
}