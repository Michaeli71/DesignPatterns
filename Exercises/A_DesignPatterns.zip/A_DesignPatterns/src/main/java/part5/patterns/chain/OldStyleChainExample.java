package part5.patterns.chain;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class OldStyleChainExample
{
    public static void main(String[] args)
    {
        Processor<String> p1 = new InfoAdder();
        Processor<String> p2 = new SpellChecker();
        Processor<String> p3 = new WordConverter();
        p1.setSuccessor(p2);
        p2.setSuccessor(p3);
        //p3.setSuccessor(p2);

        String result = p1.handle("labdas are really beautiful!");
        System.out.println(result);
    }
}
