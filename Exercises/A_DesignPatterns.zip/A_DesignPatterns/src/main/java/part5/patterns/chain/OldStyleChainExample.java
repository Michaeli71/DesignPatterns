package part5.patterns.chain;

public class OldStyleChainExample {
	public static void main(String[] args) {
		ProcessingObject<String> p1 = new HeaderTextProcessing();
		ProcessingObject<String> p2 = new SpellCheckerProcessing();
		ProcessingObject<String> p3 = new ConverterProcessing();
		p1.setSuccessor(p2);
		p2.setSuccessor(p3);

		String result = p1.handle("labdas are really beautiful!");
		System.out.println(result);
	}
}
